document.addEventListener("DOMContentLoaded", () => {
    
    console.log("JavaScript carregado corretamente.");
});
