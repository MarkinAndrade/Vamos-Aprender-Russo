
<html lang="pt-BR">

</head>
<body>
    <div class="menu">
        <ul>
            <li><a href="Aprender russo.html">Introdução</a></li>
            <li><a href="Alfabeto.html">Alfabeto</a></li>
            <li><a href="Frases Básicas I.html">Frases Básicas I</a></li>
            <li><a href="Frases para repelir e afastar pessoas.html">Frases Para Afastar</a></li>
            <li><a href="Frases para pedir informações.html">Frases Para Pedir Informações</a></li>
            <li><a href="Disciplinar passageiro.html">Frases para disciplinar passageiros</a></li>
            <li><a href="Nojo.html">Frases para expressar nojo</a></li>
            <li><a href="demissão.html">Frases para pedir demissão</a></li>
        </ul>
            </div>
<html lang="pt-BR">
<body>
       <h1>Bem-vindo ao Vamos Aprender Russo!</h1>
        <p>Bem-vindo ao nosso site dedicado ao aprendizado do russo! 
        Aqui, você encontrará recursos práticos e dinâmicos para dominar um dos idiomas 
        mais fascinantes e influentes do mundo. 
        Aqui você encontra desde as bases do alfabeto 
        cirílico até frases para xingar com algum grau de elegância, 
        nosso conteúdo é projetado para facilitar sua jornada, seja você um iniciante 
        ou alguém buscando aprimorar suas habilidades.
        Um site feito por um curioso para ajudar outros curiosos</p>
    </div>
</body>
</html>
<body>
   
</body>
</html>
   
<html>
<head>
  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
</head>
<body>
</body>
</html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    
